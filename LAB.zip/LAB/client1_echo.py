# -*- coding: utf-8 -*-
"""
Created on Sat Sep  4 08:32:26 2021

@author: kpdla
"""

import socket

HOST='127.0.0.1'
PORT=65432

with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
    s.connect((HOST,PORT))
    s.sendall(b'HAHA MSG SENT')
    data=s.recv(1024)
    
print('Recieved',repr(data))
s.close()